﻿//Write a program to print the numbers 1, 101 and 1001

using System;

class PrintNumbers
{
    static void Main()
    {
        string a = "1";
        string b = "101";
        string c = "1001";

        Console.WriteLine("{0}, {1}, {2}", a, b, c);
     }
}

