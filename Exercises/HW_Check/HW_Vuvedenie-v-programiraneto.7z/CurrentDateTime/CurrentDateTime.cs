﻿//Create a consol application that prints the current date and time.

using System;

class CurrentDateTime
{
    static void Main()
    {
        Console.Write("Current date and time: ");
        Console.WriteLine(DateTime.Now);
        Console.WriteLine();
    }
}

