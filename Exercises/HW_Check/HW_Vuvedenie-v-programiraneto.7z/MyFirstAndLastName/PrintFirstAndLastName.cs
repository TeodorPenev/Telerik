﻿//Create console application that prints your first and last name.

using System;

class PrintFirstAndLastName
{
    static void Main()
    {
        string firstName = "Falling";
        string lastName = "Angel";
        
        Console.WriteLine("My First and last name is: ");
        Console.WriteLine(firstName + " " + lastName);
    }
}

