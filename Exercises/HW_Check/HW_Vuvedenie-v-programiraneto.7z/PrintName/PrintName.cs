﻿using System;

class PrintName
{
    static void Main()
    {
        Console.WriteLine("Yana");
    }
}

