﻿//Create a console application that calculates the square of the number 12345.

using System;

class SquareOfNumber
{
    static void Main()
    {
        Console.Write("The suqare of the number 12345 is: ");
        double square = Math.Pow(12345, 2);
        Console.WriteLine(square);
    }
}

