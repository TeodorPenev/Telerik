﻿using System;

class Alphabet
{
    static void Main()
    {
        char letter = 'A';
        for (int i = 0; i < 26; i++)
        {
            Console.Write(letter + " ");
            letter++;
        }

        Console.WriteLine();
    }
}