﻿using System;

class Nums
{
    static void Main()
    {
        string input = Console.ReadLine();
        try
        {
            int num = int.Parse(input);
            Console.WriteLine("your number is: {0}", num);
        }
        catch (FormatException)
        {

            Console.WriteLine("Not a number ! ");
        }
        catch (OverflowException)
        {
            Console.WriteLine("Number is too large !");
        }

    }
}