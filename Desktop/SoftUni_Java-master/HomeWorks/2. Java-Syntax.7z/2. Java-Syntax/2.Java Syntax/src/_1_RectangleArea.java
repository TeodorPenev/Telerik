import java.util.Scanner;


public class _1_RectangleArea {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int a = input.nextInt();
		int b = input.nextInt();
		System.out.println(a*b);
	}

}
