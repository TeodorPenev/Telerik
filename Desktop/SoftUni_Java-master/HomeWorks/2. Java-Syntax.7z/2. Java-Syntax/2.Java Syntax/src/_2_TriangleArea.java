import java.util.Scanner;

public class _2_TriangleArea {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int point1Cord1 = input.nextInt();
		int point1Cord2 = input.nextInt();
		int point2Cord1 = input.nextInt();
		int point2Cord2 = input.nextInt();
		int point3Cord1 = input.nextInt();
		int point3Cord2 = input.nextInt();
		int dx1 = Math.abs(point1Cord1 - point2Cord1);
		int dy1 = Math.abs(point1Cord2 - point2Cord2);
		int dx2 = Math.abs(point2Cord1 - point3Cord1);
		int dy2 = Math.abs(point2Cord2 - point3Cord2);
		int dx3 = Math.abs(point1Cord1 - point3Cord1);
		int dy3 = Math.abs(point1Cord2 - point3Cord2);
		double A = Math.sqrt(Math.pow(dx1, 2) + Math.pow(dy1, 2));
		double B = Math.sqrt(Math.pow(dx2, 2) + Math.pow(dy2, 2));
		double C = Math.sqrt(Math.pow(dx3, 2) + Math.pow(dy3, 2));
		if (A + B > C && A + C > B && B + C > A) {
			double area = (Math.abs(point1Cord1 * (point2Cord2 - point3Cord2)
					+ point2Cord1 * (point3Cord2 - point1Cord2) + point3Cord1
					* (point1Cord2 - point2Cord2)))/2;
			System.out.println((int)area);
		} else {
			System.out.println(0);
		}

	}

}
