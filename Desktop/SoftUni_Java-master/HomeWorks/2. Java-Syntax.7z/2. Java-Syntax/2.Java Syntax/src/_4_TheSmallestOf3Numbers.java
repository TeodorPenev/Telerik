import java.util.Arrays;
import java.util.Scanner;

public class _4_TheSmallestOf3Numbers {

	public static void main(String[] args) {
	Scanner input = new Scanner(System.in);
		System.out.println("Enter a :");
		float a = input.nextFloat();
		System.out.println("Enter b :");
		float b = input.nextFloat();
		System.out.println("Enter c :");
		float c = input.nextFloat();
		float[] smallestArr =new float[]{a,b,c};
		Arrays.sort(smallestArr);
		System.out.printf("%.f",smallestArr[0]);

	}
}
