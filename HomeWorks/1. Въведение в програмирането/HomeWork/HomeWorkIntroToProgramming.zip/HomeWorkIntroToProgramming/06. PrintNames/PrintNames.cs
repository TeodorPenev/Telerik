﻿using System;
    class PrintNames
    {
        static void Main()
        {
            Console.WriteLine("Telerik Academy");
        }
    }

