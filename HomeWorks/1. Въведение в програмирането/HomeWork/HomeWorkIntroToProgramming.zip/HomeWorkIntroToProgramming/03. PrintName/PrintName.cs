﻿using System;
    class PrintName
    {
        static void Main()
        {
            Console.WriteLine("Telerik");
        }
    }

