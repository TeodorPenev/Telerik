﻿using System;
    class SquareRoot
    {
        static void Main()
        {
            Console.WriteLine(Math.Sqrt(12345));
        }
    }

