﻿using System;
    class DateTimeCurrent
    {
        static void Main()
        {
            Console.WriteLine(DateTime.Now);
        }
    }

