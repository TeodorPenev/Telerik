﻿using System;
class EmployeesRecord
    {
        static void Main()
        {
            string firstName = "Ivan";
            string familyName = "Petrov";
            byte age = 25;
            bool isMale = true;
            uint employeeNumber = 27560000;
        }
    }

