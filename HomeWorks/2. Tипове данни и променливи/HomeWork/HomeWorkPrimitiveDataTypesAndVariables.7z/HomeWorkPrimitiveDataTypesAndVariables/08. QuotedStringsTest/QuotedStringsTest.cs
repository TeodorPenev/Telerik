﻿using System;
    class QuotedStringsTest
    {
        static void Main()
        {
            string test1 = "The \"use\" of quotations causes difficulties.";
            string test2 = "The use of quotations causes difficulties."; 

            Console.WriteLine(test1);
            Console.WriteLine(test2);
        }
    }

