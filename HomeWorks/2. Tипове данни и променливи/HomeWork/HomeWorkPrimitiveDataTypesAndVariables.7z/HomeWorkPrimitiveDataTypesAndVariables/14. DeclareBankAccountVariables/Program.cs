﻿using System;
class DeclareBankAccountVariables
    {
        static void Main()
        {
            string holderName = ("First Name, Middle Name, Last Name");
            decimal mBalance = 911.10M;
            string bankName = "PostBank";
            string iBan = "IT96W0585611601050570111111";
            string bIC = "PRCBBGS";
            ulong creditCard1 = 1214519036076404; 
            ulong creditCard2 = 139398053299994; 
            ulong creditCard3 = 37456760168770;
        }
    }

