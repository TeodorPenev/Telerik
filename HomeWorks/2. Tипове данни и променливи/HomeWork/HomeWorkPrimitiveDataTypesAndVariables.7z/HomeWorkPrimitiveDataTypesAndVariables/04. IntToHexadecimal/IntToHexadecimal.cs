﻿using System;
    class IntToHexadecimal
    {
        static void Main()
        {
            int n = 254;
            Console.WriteLine(Convert.ToString(n,16));
        }
    }

