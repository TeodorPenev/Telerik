﻿using System;
    class DoubleOrFloat
    {
        static void Main()
        {
            double n1 = 34.567839023;
            float n2 = 12.345f;
            double n3 = 8923.1234857;
            float n4 = 3456.091f;
        }
    }

