﻿using System;
class BooleanGender
    {
        static void Main()
        {
            bool  isFemale = false;
            Console.WriteLine("My gender is female:{0}" , isFemale);
        }
    }

