﻿using System;
class UnicodeToChar
{
    static void Main()
    {
        char symbolInHex = '\u0048';
        Console.WriteLine("The symbol is: {0}",symbolInHex);
    }
}



